﻿
██████╗░██╗░██████╗░█████╗░██╗░░░░░░█████╗░███╗░░░███╗███████╗██████╗░  ██╗
██╔══██╗██║██╔════╝██╔══██╗██║░░░░░██╔══██╗████╗░████║██╔════╝██╔══██╗  ╚═╝
██║░░██║██║╚█████╗░██║░░╚═╝██║░░░░░███████║██╔████╔██║█████╗░░██████╔╝  ░░░
██║░░██║██║░╚═══██╗██║░░██╗██║░░░░░██╔══██║██║╚██╔╝██║██╔══╝░░██╔══██╗  ░░░
██████╔╝██║██████╔╝╚█████╔╝███████╗██║░░██║██║░╚═╝░██║███████╗██║░░██║  ██╗
╚═════╝░╚═╝╚═════╝░░╚════╝░╚══════╝╚═╝░░╚═╝╚═╝░░░░░╚═╝╚══════╝╚═╝░░╚═╝  ╚═╝

This map uses a data pack by IJAMinecraft. You can find it on ijaminecraft.com/map/oneblock/
I have renamed every scoreboard in this datapack from "ija" to "gz". I have edited everything in this datapack.


███ ████ ████ █   █ ███ █   █ ████  ██  ███  ████ ████ █████
 █     █ █  █ ██ ██  █  ██  █ █    █  █ █  █ █  █ █      █
 █     █ ████ █ █ █  █  █ █ █ ████ █    ███  ████ ████   █
 █  █  █ █  █ █   █  █  █  ██ █    █  █ █  █ █  █ █      █
███  ██  █  █ █   █ ███ █   █ ████  ██  █  █ █  █ █      █

This work was created and is copyrighted by IJAMinecraft.
License: https://ijaminecraft.com/copyright

Visit IJAMinecraft here:
Website: ijaminecraft.com
YouTube: youtube.com/user/IJAMinecraft
